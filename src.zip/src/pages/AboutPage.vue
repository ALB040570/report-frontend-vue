<template>
  <section class="page">
    <h1>О проекте</h1>
    <p>Report Constructor — интерактивное приложение для сборки кастомных отчётов.</p>
  </section>
</template>
<script setup></script>
<style scoped>
.page {
  padding: 16px;
}
</style>
